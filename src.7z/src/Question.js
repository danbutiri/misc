import React from 'react';
import logo from './logo.svg';

function Question(props) {
	
	
  return (
    <div className="Question">
    
			<input value="Adauga inrebare" id={`${props.id_test}question`}/>

			<input value="Raspuns" id={`${props.id_test}raspuns_1`}/>
			<input value="Raspuns" id={`${props.id_test}raspuns_2`}/>
			<input value="Raspuns" id={`${props.id_test}raspuns_3`}/>
			<input value="Raspuns" id={`${props.id_test}raspuns_4`}/>
    </div>
  );
}

export default Question;
