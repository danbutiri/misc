import React,{useState} from 'react';
import Question from './Question';
import './App.css';



function App() {
	const [intrebari, set_intrebari] = useState([]);
	const [nr_intrebari,set_nr_intrebari] = useState(0);
  
  let adauga_intrebare=()=> {
	  set_nr_intrebari(nr_intrebari+1);
	  set_intrebari([...intrebari, `${nr_intrebari}`])
  }
  
  return (
    <div className="App">
		{ intrebari.map( Element => <Question id_test={Element}/>)

		}

	
		<button onClick={adauga_intrebare}>Adauga intrebare</button>
		<br/>
	
		<button>Salveaza si trimite</button>

		{intrebari}
    </div>
  );
}

export default App;
